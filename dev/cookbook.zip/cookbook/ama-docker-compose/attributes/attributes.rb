default['ama-docker-compose']['version'] = '1.16.1'
