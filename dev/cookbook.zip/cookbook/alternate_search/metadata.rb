name             'alternate_search'
maintainer       'DataSift'
maintainer_email 'opensource@datasift.com'
license          'mit'
description      'An alternate search syntax for Chef'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '2.3.0'
depends          'partial_search'
