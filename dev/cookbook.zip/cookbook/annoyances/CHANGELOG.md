## v0.4.1
* ignore_failure added for byobu service

## v0.4.0
* updated for Chef 11 (@alanthing)
* fixed use of include? (@mikedillion)
* Red Hat enables some ridiculous services by default on servers (@blasdelf)
* support running in chef-solo (@blasdelf)
* don't disable byobu if the cookbook for it is in use (@blasdelf)

## v0.3.0
* refactored to use platform_family (thanks @jtimberman)

## v0.2.0

* added popcon to ubuntu and cleaned up metadata a bit
* documented use of recipes directly to keep them in the run list

## v0.1.0:

* initial release, recipes for ubuntu and debian
