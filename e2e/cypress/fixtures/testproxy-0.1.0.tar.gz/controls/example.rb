# copyright: 2018, The Authors

title "test if proxy is set"

# you add controls here
control "check proxy1" do                        # A unique ID for this control
  impact 0.7                                # The criticality, if this control fails.
  title "Checks if https proxy is set"             # A human-readable title
  desc "Proxy value is set to environment"
  describe os_env('https_proxy').content.to_s.split(':') do
    it { should_not be_empty }
  end
end