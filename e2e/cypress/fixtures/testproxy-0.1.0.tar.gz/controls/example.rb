# copyright: 2018, The Authors

title "sample section"

# you add controls here
control "check proxy" do                        # A unique ID for this control
  impact 0.7                                # The criticality, if this control fails.
  title "Checks if http proxy is set"             # A human-readable title
  desc "Proxy value is set to environment"
  describe ENV['http_proxy'] do                  # The actual test
    it { should_not match nil}
  end
end
# you add controls here
control "check proxy1" do                        # A unique ID for this control
  impact 0.7                                # The criticality, if this control fails.
  title "Checks if https proxy is set"             # A human-readable title
  desc "Proxy value is set to environment"
  describe ENV['https_proxy'] do                  # The actual test
    it { should_not match nil}
  end
end