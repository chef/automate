# audit cookbook attributes:
default['audit']['compliance_phase'] = true
default['audit']['reporter'] = 'chef-server-automate'
default['audit']['fetcher'] = 'chef-server'
default['audit']['profiles']['linux-baseline'] = { 'compliance': 'admin/linux-baseline', 'version': '2.2.2' }
