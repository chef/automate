Connections
===========

.. autoclass:: urllib3.connection.HTTPConnection
    :members:
    :exclude-members: putrequest
    :show-inheritance:

.. autoclass:: urllib3.connection.HTTPSConnection
    :members:
    :show-inheritance:
