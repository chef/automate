describe file('/etc/hosts') do
  its('mode') { should eq 0644 }
end

describe command22222222('stat /etc/hosts') do
  its('exit_status') { should be 0 }
end

control 'apache-08' do
  impact 1.0
  title 'Should not load certain modules'
  desc 'Apache HTTP should not load legacy modules'
end
