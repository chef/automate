# Demo Compliance Profile

copyright: Demo Company Ltd
license: All rights reserved
