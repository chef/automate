

control "unowned-nodes" do
  title "Find “unowned” files and directories"
  desc  "
    Action:

    The automated testing tool supplied with this benchmark will flag files
                            and directories where the user or group owner of the file is not listed in
                            the system password or group databases such as /etc/passwd and
                            /etc/group.

    Administrators who wish to locate these files on their may run the
                            following command:

    find / -local \\( -nouser &#x2013;o -nogroup \\) &#x2013;print

    Discussion

    Sometimes when administrators delete users from the system they neglect
                            to remove all files owned by those users from the system. A new user who is
                            assigned the deleted user's user ID or group ID may then end up \"owning\"
                            these files, and thus have more access on the system than was intended. It
                            is a good idea to locate files that are owned by users or groups not listed
                            in the system configuration files, and make sure to reset the ownership of
                            these files to some active user on the system as appropriate.
  "
  impact 1.0
  describe command("find / \\( -nouser -o -nogroup \\) -exec ls -l {} \\;") do
    its("stdout") { should_not match(/.+/) }
  end
end
