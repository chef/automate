control 'iptables-001' do
  impact 0.8
  title '0.0.1 - iptables is on'
  tag 'firewall','iptables'
  tag cce: 'CCE-27072-8'
  ref 'NSA-RH6-STIG - Section 3.5.2.1', url: 'https://www.nsa.gov/ia/_files/os/redhat/rhel5-guide-i731.pdf'
  desc '
    iptables service is installed
    iptables service is enabled to start at boot
    iptables service is running
  '
  describe service('iptables') do
    it { should be_installed }
    it { should be_enabled }
    it { should be_running }
  end
end
