# Basic Linux Compliance Profile

copyright: 2015, Chef Software, Inc
license: All rights reserved
