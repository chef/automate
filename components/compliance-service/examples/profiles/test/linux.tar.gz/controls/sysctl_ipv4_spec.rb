# encoding: utf-8
# copyright: 2015, Dominik Richter
# license: All rights reserved

title 'Sysctl IPv4 Settings'

control 'basic-1' do
  impact 1.0
  title '/etc/ssh should be a directory'
  desc '
    In order for OpenSSH to function correctly, its
    configuration path must be a folder.
  '
  describe file('/etc/ssh') do
    it { should be_directory }
  end
end

control 'sysctl-ipv4-1.1' do
  impact 0.5
  title 'Disable global IP forwarding'
  desc "
    Regular nodes, which don't route/forward traffic
    should have this option disabled.
  "
  describe kernel_parameter('net.ipv4.ip_forward') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-1.2' do
  impact 0.5
  title 'Disable IP forwarding on all devices'
  desc "
    Regular nodes, which don't route/forward traffic
    should have this option disabled.
  "
  describe kernel_parameter('net.ipv4.conf.all.forwarding') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-2.1' do
  impact 0.5
  title 'Set rp_filter to 1 for all devices'
  desc '
    Instruct the kernel to do source validation by
    confirming the reverse path.
  '
  describe kernel_parameter('net.ipv4.conf.all.rp_filter') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-2.2' do
  impact 0.5
  title 'Set rp_filter to 1 by default'
  desc '
    Instruct the kernel to do source validation by
    confirming the reverse path.
  '
  describe kernel_parameter('net.ipv4.conf.default.rp_filter') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-3' do
  impact 0.5
  title 'Ignore ICMP echo broadcasts'
  desc "
    Don't respond to broadcast ICMP messages. This mechanism
    can be used for resource starvation on the network.
  "
  describe kernel_parameter('net.ipv4.icmp_echo_ignore_broadcasts') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-4' do
  impact 0.5
  title 'Ignore bogus ICMP error responses'
  desc '
    Ignore all bogus ICMP error messages.
  '
  describe kernel_parameter('net.ipv4.icmp_ignore_bogus_error_responses') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-5' do
  impact 0.5
  title 'Specify a ratelimit for ICMP messages'
  desc '
    For all messages specified in the ratemask,
    limit the rate of responses to avoid resource starvation.
  '
  describe kernel_parameter('net.ipv4.icmp_ratelimit') do
    its('value') { should eq 100 }
  end
end

control 'sysctl-ipv4-6' do
  impact 0.5
  title 'Specify a ratemask for ICMP messages'
  desc '
    For all messages specified in the ratemask,
    limit the rate of responses to avoid resource starvation.
  '
  describe kernel_parameter('net.ipv4.icmp_ratemask') do
    its('value') { should eq 88089 }
  end
end

control 'sysctl-ipv4-7' do
  impact 0.5
  title 'Do not use TCP timestamps'
  desc '
    Avoid TCP timestamps, which can be used to gain
    information on the system and network.
  '
  describe kernel_parameter('net.ipv4.tcp_timestamps') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-8.1' do
  impact 0.5
  title 'Enable ARP ignore'
  desc '
    Reply to requests only if the target IP is configured
    on the requested interface.
  '
  describe kernel_parameter('net.ipv4.conf.all.arp_ignore') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-8.2' do
  impact 0.5
  title 'Restrict ARP announcements'
  desc '
    Select the best local address on ARP requests.
  '
  describe kernel_parameter('net.ipv4.conf.all.arp_announce') do
    its('value') { should eq 2 }
  end
end

control 'sysctl-ipv4-9.1' do
  impact 0.5
  title 'Behave as described in RFC 1337'
  desc '
    Let TIME_WAIT packets idle out even if a RST is received,
    as described in RFC 1337
  '
  describe kernel_parameter('net.ipv4.tcp_rfc1337') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-9.2' do
  impact 1.0
  title 'Enable TCP syn-cookies'
  desc '
    Avoid DoS TCP SYN attacks, by enabling SYN cookies.
  '
  describe kernel_parameter('net.ipv4.tcp_syncookies') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-10.1' do
  impact 0.5
  title 'Enable shared_media to avoid disabling secure_redirects on all devices'
  desc '
    Indicates that the device is shared with different subnets.
    Do not disable this setting as it will disable secure_redirects.
  '
  describe kernel_parameter('net.ipv4.conf.all.shared_media') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-10.2' do
  impact 0.5
  title 'Enable shared_media to avoid disabling secure_redirects by default'
  desc '
    Indicates that the device is shared with different subnets.
    Do not disable this setting as it will disable secure_redirects.
  '
  describe kernel_parameter('net.ipv4.conf.default.shared_media') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv4-11.1' do
  impact 0.5
  title 'Do not accept source routes on all devices'
  desc '
    For regular nodes on the network, do not accept source routes.
    This can be used to redirect traffics through the network and
    could be used avoid security gates.
  '
  describe kernel_parameter('net.ipv4.conf.all.accept_source_route') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-11.2' do
  impact 0.5
  title 'Do not accept source routes by default'
  desc '
    For regular nodes on the network, do not accept source routes.
    This can be used to redirect traffics through the network and
    could be used avoid security gates.
  '
  describe kernel_parameter('net.ipv4.conf.default.accept_source_route') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-12.2' do
  impact 0.5
  title 'Disable accepting redirects on all devices'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv4.conf.all.accept_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-12.1' do
  impact 0.5
  title 'Disable accepting redirects by default'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv4.conf.default.accept_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-13.1' do
  impact 0.5
  title 'Disable all redirects on all devices'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv4.conf.all.secure_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-13.2' do
  impact 0.5
  title 'Disable all redirects by default'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv4.conf.default.secure_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-14.1' do
  impact 0.5
  title 'Disable sending redirects on all devices'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv4.conf.all.send_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-14.2' do
  impact 0.5
  title 'Disable sending redirects by default'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv4.conf.default.send_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-15.1' do
  impact 0.3
  title 'Disable logging martians on all devices'
  desc '
    Avoid resource starvation on the server by disabling
    logging martians on production systems. It may still be useful
    for debugging and analysis purposes.
  '
  describe kernel_parameter('net.ipv4.conf.all.log_martians') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv4-15.2' do
  impact 0.3
  title 'Disable logging martians by default'
  desc '
    Avoid resource starvation on the server by disabling
    logging martians on production systems. It may still be useful
    for debugging and analysis purposes.
  '
  describe kernel_parameter('net.ipv4.conf.default.log_martians') do
    its('value') { should eq 0 }
  end
end
