# encoding: utf-8
# copyright: 2015, Chef Software, Inc
# license: All rights reserved

title 'sysctl Settings'

control 'sysctl-1' do
  impact 0.5
  title 'Do not accept SysRQs'
  desc '
    SysRQs are not needed on a regular networked
    node, so disable them.
  '
  describe kernel_parameter('kernel.sysrq') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-2' do
  impact 0.5
  title 'Avoid core dumps'
  desc '
    Avoid all forms of core dumps, as information
    may be gathered from it by attackers.
  '
  describe kernel_parameter('fs.suid_dumpable') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-3' do
  impact 0.5
  title 'Without NX enabled, enforce exec-shield'
  desc '
    If the CPU has NX enabled, buffer overflows are
    well diminished through the CPU. If this setting is not
    available, then at least enable the exec-shield feature
    in the kernel.
  '
  # if no nx flag is present, we require exec-shield
  describe 'No nx flag detected' do
    it 'require kernel.exec-shield' do
      if command('cat /proc/cpuinfo').stdout =~ /^flags.*?:.*? nx( .*?)?$/
        expect(true).to be true
      else
        expect(kernel_parameter('kernel.exec-shield').value).to eq 1
      end
    end
  end
end

control 'sysctl-4' do
  impact 0.5
  title 'Set full address space layout randomization'
  desc '
    Address space randomization makes attacks via
    overflows more difficult.
  '
  describe kernel_parameter('kernel.randomize_va_space') do
    its('value') { should eq 2 }
  end
end
