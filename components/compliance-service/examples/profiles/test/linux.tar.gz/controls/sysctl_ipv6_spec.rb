# encoding: utf-8
# copyright: 2015, Dominik Richter
# license: All rights reserved

title 'Sysctl IPv6 Settings'

control 'sysctl-ipv6-1' do
  impact 0.5
  title 'For regular IPv4-only servers, disable IPv6'
  desc '
    Unless explicitly needed, do not enable
    IPv6 on the node to reduce the attack surface.
  '
  describe kernel_parameter('net.ipv6.conf.all.disable_ipv6') do
    its('value') { should eq 1 }
  end
end

control 'sysctl-ipv6-2' do
  impact 0.5
  title 'Disable IP forwarding on regular nodes'
  desc "
    Regular nodes, which don't route/forward traffic
    should have this option disabled.
  "
  describe kernel_parameter('net.ipv6.conf.all.forwarding') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-3.1' do
  impact 0.5
  title 'Disable accepting redirects by default'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv6.conf.default.accept_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-3.2' do
  impact 0.5
  title 'Disable accepting redirects on all devices'
  desc '
    Disable all types of redirects on regular nodes which are
    not routers
  '
  describe kernel_parameter('net.ipv6.conf.all.accept_redirects') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-4' do
  impact 0.5
  title 'Disable router solicitations'
  desc '
    Disable all sysctl functions that are only relevant,
    if this machine is a router.
  '
  describe kernel_parameter('net.ipv6.conf.default.router_solicitations') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-5' do
  impact 0.5
  title 'Do not accept router preference in router advertisement'
  desc '
    Disable all sysctl functions that are only relevant,
    if this machine is a router.
  '
  describe kernel_parameter('net.ipv6.conf.default.accept_ra_rtr_pref') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-6' do
  impact 0.5
  title 'Do not learn prefix information in router advertisement'
  desc '
    Disable all sysctl functions that are only relevant,
    if this machine is a router.
  '
  describe kernel_parameter('net.ipv6.conf.default.accept_ra_pinfo') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-7' do
  impact 0.5
  title 'Do not accept hop limit settings in router advertisement'
  desc '
    Disable all sysctl functions that are only relevant,
    if this machine is a router.
  '
  describe kernel_parameter('net.ipv6.conf.default.accept_ra_defrtr') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-8' do
  impact 0.5
  title 'Do not let router advertisements assign a global unicast address'
  desc '
    Disable all sysctl functions that are only relevant,
    if this machine is a router.
  '
  describe kernel_parameter('net.ipv6.conf.default.autoconf') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-9' do
  impact 0.5
  title 'Do not send neighborhood solicitations per address'
  desc '
    Disable all sysctl functions that are only relevant,
    if this machine is a router.
  '
  describe kernel_parameter('net.ipv6.conf.default.dad_transmits') do
    its('value') { should eq 0 }
  end
end

control 'sysctl-ipv6-10' do
  impact 0.5
  title 'Only allow one global unicast address per interface'
  desc '
    Avoid having different unicast addresses per interface.
  '
  describe kernel_parameter('net.ipv6.conf.default.max_addresses') do
    its('value') { should eq 1 }
  end
end
