# encoding: utf-8
# copyright: 2015, Chef Software, Inc
# license: All rights reserved

title 'Filesystem Configuration'

control 'fs-1' do
  impact 0.5
  title 'Create a separate partition for /tmp'
  desc '
    Since /tmp is world-writable, avoid resource
    exhaustion on the host by mounting this folder
    to a separate partition.
  '
  describe mount('/tmp') do
    it { should be_mounted }
  end
end

control 'fs-2' do
  impact 0.5
  title 'Set nodev option for /tmp partition'
  desc '
    Since /tmp should not support devices,
    set the nodev option to prevent the user from
    creating special devices.
  '
  describe mount('/tmp') do
    its('options') { should include 'nodev' }
  end
end

control 'fs-3' do
  impact 0.5
  title 'Set nosuid option for /tmp partition'
  desc '
    Since /tmp is intended for temporary file storage only,
    set the nosuid option to prevent setuid executables.
  '
  describe mount('/tmp') do
    its('options') { should include 'nosuid' }
  end
end

control 'fs-4' do
  impact 0.5
  title 'Set noexec option for /tmp partition'
  desc '
    Since /tmp is intended for temporary file storage only,
    set the noexec option to prevent executable files.
    Shared executables may be manipulated by other users.
    Running these indicates a serious vulnerability.
  '
  describe mount('/tmp') do
    its('options') { should include 'noexec' }
  end
end
